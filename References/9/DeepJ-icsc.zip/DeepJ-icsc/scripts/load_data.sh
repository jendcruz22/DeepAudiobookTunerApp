# Run this file from the parent dir of the repository
y | sudo apt-get install unzip

mkdir -p ./music-generator/data
unzip data.zip -d ./music-generator/data
